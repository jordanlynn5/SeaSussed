// extension/sidepanel.js

const STORAGE_KEY = 'seasussed_onboarded';

const GRADE_COLORS = { A: '#22c55e', B: '#eab308', C: '#f97316', D: '#ef4444' };
const GRADE_LABELS = { A: '🟢 Best Choice', B: '🟡 Good Alternative', C: '🟠 Use Caution', D: '🔴 Avoid' };
const GRADE_EMOJI  = { A: '🟢', B: '🟡', C: '🟠', D: '🔴' };
const BREAKDOWN_MAX = { biological: 20, practices: 25, management: 30, ecological: 25 };
const SCORE_FILL_COLOR = { A: '#16a34a', B: '#ca8a04', C: '#ea580c', D: '#dc2626' };

/** Escape a string for safe insertion into innerHTML. */
function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Cert definitions (static — never Gemini-generated)
const CERT_DEFINITIONS = {
  'MSC': {
    full_name: 'Marine Stewardship Council',
    explanation: 'The MSC blue fish logo means this fishery was independently audited against science-based standards. To earn MSC, a fishery must show healthy fish stocks, minimal environmental impact, and effective management systems. Annual surveillance audits maintain the certification.',
  },
  'ASC': {
    full_name: 'Aquaculture Stewardship Council',
    explanation: 'The ASC teal logo certifies responsibly farmed seafood. ASC farms meet standards covering feed sourcing, disease and chemical use, water quality, ecosystem impacts, and worker welfare. Considered the gold standard for farmed seafood certification.',
  },
  'BAP': {
    full_name: 'Best Aquaculture Practices',
    explanation: 'BAP certifies farmed seafood across four supply chain areas: hatcheries, farms, processing, and feed mills. The number of stars shows how many components are certified — more stars means greater traceability and sustainability verification.',
  },
  'GLOBALG.A.P.': {
    full_name: 'GlobalG.A.P.',
    explanation: 'GlobalG.A.P. certifies farms against food safety, environmental sustainability, and worker welfare standards. Respected internationally but less seafood-specific than ASC or BAP.',
  },
  'FRIEND OF THE SEA': {
    full_name: 'Friend of the Sea',
    explanation: 'Certifies both wild-caught and farmed seafood against sustainability criteria including stock status, bycatch reduction, and no impact on endangered species or seabed. Widely recognized internationally.',
  },
  'FOS': {
    full_name: 'Friend of the Sea',
    explanation: 'Friend of the Sea (FOS) certifies both wild-caught and farmed seafood against sustainability criteria including stock status, bycatch reduction, and no impact on endangered species or seabed.',
  },
  'ASMI': {
    full_name: 'Alaska Seafood Marketing Institute',
    explanation: 'The Alaska Seafood logo indicates seafood from Alaska — one of the world\'s best-managed fisheries regions. All Alaska commercial fisheries operate under the Magnuson-Stevens Act with science-based catch limits and independent stock assessments.',
  },
  'SUSTAINABLY SOURCED': {
    full_name: 'Sustainably Sourced (retailer claim)',
    explanation: '\'Sustainably sourced\' is an unverified marketing claim — not backed by independent audit. Unlike MSC or ASC, there\'s no standard defining what it means. Look for the MSC blue fish logo or ASC teal logo for independently verified sustainability.',
  },
  'RESPONSIBLY FARMED': {
    full_name: 'Responsibly Farmed (retailer claim)',
    explanation: '\'Responsibly Farmed\' is a retailer-defined standard audited by the retailer itself, not an independent body. A step above no label, but not equivalent to ASC or BAP certification.',
  },
  'SEAFOOD WATCH': {
    full_name: 'Monterey Bay Aquarium Seafood Watch',
    explanation: 'Seafood Watch is a science-based consumer guide from the Monterey Bay Aquarium rating seafood as Best Choice, Good Alternative, or Avoid. It\'s a rating system, not a certification (no logo on packaging) — but widely respected by restaurants and retailers.',
  },
};

let currentResult = null;
let voiceClient = null;
let pendingVoiceData = null; // held while mic-permission popup is open
let _lastVoiceData = null;
let _pendingScoreReveal = null; // held until 'complete' phase arrives
let _analyzeController = null; // AbortController for in-flight /analyze/stream fetch

// Build animation timers (cancelled if new data arrives mid-animation)
let _buildTimers = [];
let _cooldownInterval = null;
let _latestHealth = null; // captured from SSE health phase for voice context
function _scheduleBuild(fn, delay) { _buildTimers.push(setTimeout(fn, delay)); }
function _cancelBuild() { _buildTimers.forEach(clearTimeout); _buildTimers = []; }

// Receive grant from mic-permission.html popup and start voice
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'MIC_PERMISSION_GRANTED' && pendingVoiceData) {
    const { data } = pendingVoiceData;
    pendingVoiceData = null;
    connectVoice(data);
  }
});

// ── View management ──
function showView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(id)?.classList.add('active');
}

// ── Init: check if onboarded ──
chrome.storage.local.get(STORAGE_KEY, (res) => {
  showView(res[STORAGE_KEY] ? 'view-idle' : 'view-onboarding');
});

// ── Onboarding ──
document.getElementById('onboarding-ok')?.addEventListener('click', () => {
  chrome.storage.local.set({ [STORAGE_KEY]: true });
  showView('view-idle');
});

// ── Voice bar (inside view-result) ──
function showVoiceBar(text) {
  const bar = document.getElementById('voice-bar');
  if (bar) bar.style.display = 'flex';
  const s = document.getElementById('voice-bar-status');
  if (s) s.textContent = text;
}

function playNotificationTone() {
  // Short rising tone to signal activity (non-jarring, no voice change)
  try {
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.setValueAtTime(600, ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(900, ctx.currentTime + 0.15);
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.2);
    osc.start();
    osc.stop(ctx.currentTime + 0.2);
    setTimeout(() => ctx.close(), 300);
  } catch (_) {}
}

function updateVoiceBar(state) {
  const dot = document.getElementById('voice-bar-indicator');
  const status = document.getElementById('voice-bar-status');
  if (!dot || !status) return;

  if (state === 'expired' || state === 'disconnected') {
    dot.className = 'vbar-dot';
    const msg = state === 'expired' ? 'Session expired' : 'Connection lost';
    status.innerHTML = `${msg} &mdash; <button id="voice-reconnect-btn" class="vbar-reconnect">Reconnect</button>`;
    document.getElementById('voice-reconnect-btn')?.addEventListener('click', () => {
      stopVoiceBar();
      if (_lastVoiceData) connectVoice(_lastVoiceData);
    });
    return;
  }

  const thinkingStates = ['thinking', 'searching', 'analyzing', 'navigating', 'reconnecting'];
  const dotClass = state === 'speaking' ? ' speaking'
    : thinkingStates.includes(state) ? ' thinking' : '';
  dot.className = 'vbar-dot' + dotClass;
  const labels = {
    listening: 'Listening\u2026',
    thinking: 'Thinking\u2026',
    searching: 'Searching the store\u2026',
    analyzing: 'Analyzing product\u2026',
    navigating: 'Opening product page\u2026',
    speaking: 'Speaking\u2026',
    reconnecting: 'Reconnecting\u2026',
  };
  if (labels[state]) status.textContent = labels[state];
  // Audio cue so user knows something is happening during silence
  if (state === 'searching' || state === 'analyzing') playNotificationTone();
  if (state === 'ended' || state === 'error') stopVoiceBar();
}

function stopVoiceBar() {
  if (voiceClient) { voiceClient.stop(); voiceClient = null; }
  const bar = document.getElementById('voice-bar');
  if (bar) bar.style.display = 'none';
}

document.getElementById('voice-bar-stop')?.addEventListener('click', stopVoiceBar);

async function connectVoice(data, preStream = null) {
  if (voiceClient !== null) {
    if (preStream) preStream.getTracks().forEach(t => t.stop());
    return;
  }
  _lastVoiceData = data;
  voiceClient = new VoiceClient();
  voiceClient.onStatus = updateVoiceBar;
  voiceClient.onScoreResult = (score) => {
    if (!score?.product_info?.is_seafood) return;
    currentResult = score;
    renderResult(score);
  };
  voiceClient.onError = () => stopVoiceBar();
  voiceClient.onAudioActivity = () => {
    const dot = document.getElementById('voice-bar-indicator');
    if (!dot) return;
    dot.classList.add('mic-active');
    clearTimeout(dot._activityTimer);
    dot._activityTimer = setTimeout(() => dot.classList.remove('mic-active'), 150);
  };
  showVoiceBar('Connecting…');
  try {
    await voiceClient.start(preStream);
    updateVoiceBar('listening');
    voiceClient.sendResultContext({
      analyzing: data.analyzing || false,
      score: data.score,
      grade: data.grade,
      species: data.product_info?.species ?? null,
      wild_or_farmed: data.product_info?.wild_or_farmed ?? 'unknown',
      all_products: data.all_products ?? null,
      listing_summary: data.listing_summary ?? null,
    });
  } catch (err) {
    console.warn('[SeaSussed] Voice start failed:', err.message);
    stopVoiceBar();
    voiceClient = null;
  }
}

async function startVoiceAfterResult(data) {
  // Check current mic permission state.
  // If already granted, connect directly.
  // If prompt/unknown, open a dedicated popup page — getUserMedia from the popup's
  // button-click handler is the most reliable way to trigger Chrome's permission dialog
  // (side panel pages don't reliably surface the prompt in all Chrome versions).
  let micState = 'prompt';
  try {
    const perm = await navigator.permissions.query({ name: 'microphone' });
    micState = perm.state;
  } catch (_) { /* Permissions API unavailable — assume prompt */ }

  if (micState === 'denied') return; // mic blocked — skip silently

  if (micState === 'granted') {
    connectVoice(data);
    return;
  }

  // 'prompt' — open mic-permission.html popup; it sends MIC_PERMISSION_GRANTED on success
  pendingVoiceData = { data };
  const bar = document.getElementById('voice-bar');
  const status = document.getElementById('voice-bar-status');
  if (bar) bar.style.display = 'flex';
  if (status) {
    status.innerHTML = '<button id="voice-enable-btn" class="vbar-enable">Enable Voice</button>';
    document.getElementById('voice-enable-btn')?.addEventListener('click', () => {
      // Open as a tab — Chrome reliably shows the getUserMedia permission prompt
      // for extension pages opened as tabs; popup windows can fail with NotFoundError.
      chrome.tabs.create({
        url: chrome.runtime.getURL('mic-permission.html'),
        active: true,
      });
    });
  }
}

const ANALYZE_BTN_IDS = ['analyze-btn', 'analyze-again-btn', 'list-analyze-again-btn'];
function _setAnalyzeBtnsDisabled(disabled) {
  ANALYZE_BTN_IDS.forEach(id => {
    const btn = document.getElementById(id);
    if (btn) btn.disabled = disabled;
  });
}

// ── Analyze ──
async function triggerAnalyze() {
  _cancelBuild();

  // Abort any in-flight analysis before starting a new one
  if (_analyzeController) {
    _analyzeController.abort();
    _analyzeController = null;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  _setAnalyzeBtnsDisabled(true);
  showView('view-loading');
  setLoadingStatus('Capturing page data…');
  // Reset health + food miles cards for new analysis
  _latestHealth = null;
  document.getElementById('health-card').style.display = 'none';
  document.getElementById('food-miles-card').style.display = 'none';

  // Start voice immediately — Gemini greets while analysis runs
  if (!voiceClient) {
    startVoiceAfterResult({ analyzing: true });
  }

  _analyzeController = new AbortController();
  const signal = _analyzeController.signal;
  // Auto-timeout after 60s
  const timeout = setTimeout(() => _analyzeController?.abort(), 60000);

  try {
    // Step 1: Capture screenshot + gallery images + DOM text via background.js
    const pageData = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: 'CAPTURE_PAGE_DATA', tabId: tab.id, url: tab.url },
        (result) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else if (result?.error) reject(new Error(result.error));
          else resolve(result);
        }
      );
    });

    if (signal.aborted) return;

    setLoadingStatus('Identifying product…');

    // Step 2: Stream results from backend via SSE
    const response = await fetch(`${BACKEND_URL}/analyze/stream`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        screenshot: pageData.screenshot,
        url: pageData.url,
        page_title: pageData.pageTitle,
        page_text: pageData.pageText,
        product_images: pageData.productImages,
        related_products: pageData.relatedProducts,
        related_products_with_urls: pageData.relatedProductsWithUrls ?? [],
      }),
      signal,
    });

    if (!response.ok) {
      const text = await response.text();
      throw new Error(`Backend error ${response.status}: ${text.substring(0, 120)}`);
    }

    // Read SSE stream
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || ''; // keep incomplete line in buffer

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          try {
            const data = JSON.parse(line.slice(6));
            handleSSEEvent(data, pageData);
          } catch (parseErr) {
            console.warn('[SeaSussed] SSE JSON parse error:', parseErr, line);
          }
        }
      }
    } finally {
      reader.releaseLock();
    }
  } catch (err) {
    // Silently ignore aborts from a superseding triggerAnalyze() call
    if (err.name === 'AbortError') return;
    showError('Analysis failed — please try again.');
    console.error('[SeaSussed] triggerAnalyze error:', err);
  } finally {
    clearTimeout(timeout);
    _analyzeController = null;
    _setAnalyzeBtnsDisabled(false);
  }
}

function setLoadingStatus(text) {
  const el = document.getElementById('loading-status');
  if (el) el.textContent = text;
}

function renderHealthCard(health) {
  if (!health) return;
  const card = document.getElementById('health-card');
  const body = document.getElementById('health-card-body');

  const gradeColors = { A: '#16a34a', B: '#ca8a04', C: '#ea580c', D: '#dc2626' };
  const color = gradeColors[health.health_grade] || '#6b7280';

  let html = `<div style="font-weight:600; color:${color}; margin-bottom:4px;">`;
  html += `${escapeHtml(health.mercury_category)}`;
  if (health.mercury_ppm != null) {
    html += ` <span style="font-weight:400; color:#9ca3af;">(${escapeHtml(String(health.mercury_ppm))} ppm mercury)</span>`;
  }
  html += `</div>`;
  if (health.omega3_note) {
    html += `<div>${escapeHtml(health.omega3_note)}</div>`;
  }
  if (health.serving_advice) {
    html += `<div style="color:#6b7280; font-size:12px; margin-top:2px;">${escapeHtml(health.serving_advice)}</div>`;
  }
  body.innerHTML = html;
  card.style.display = '';
}

function renderFoodMilesCard(foodMiles) {
  if (!foodMiles) return;
  const card = document.getElementById('food-miles-card');
  const body = document.getElementById('food-miles-card-body');

  const distFormatted = foodMiles.distance_miles.toLocaleString();

  let html = `<div style="font-weight:600; margin-bottom:4px;">`;
  html += `~${escapeHtml(distFormatted)} miles`;
  html += `</div>`;
  html += `<div style="color:#6b7280; font-size:12px;">`;
  html += `${escapeHtml(foodMiles.origin)} → ${escapeHtml(foodMiles.destination)}`;
  html += `</div>`;
  html += `<div style="color:#9ca3af; font-size:11px; margin-top:4px;">Source: ${escapeHtml(foodMiles.source)}</div>`;
  body.innerHTML = html;
  card.style.display = '';
}

function handleSSEEvent(data, pageData) {
  if (data.phase === 'analyzing') {
    setLoadingStatus('Analyzing all images…');
    return;
  }

  if (data.phase === 'health') {
    _latestHealth = data.health;
    renderHealthCard(data.health);
    return;
  }

  if (data.phase === 'scored') {
    // Progressive phase 1: show product info + score immediately
    renderScorePhase(data);
    return;
  }

  if (data.phase === 'food_miles') {
    renderFoodMilesCard(data.food_miles);
    return;
  }

  if (data.phase === 'enriched') {
    // Research found new data — update pending reveal with enriched score
    // (do NOT set the grade badge directly — wait for 'complete' phase)
    const { score, grade, product_info } = data;
    if (_pendingScoreReveal) {
      _pendingScoreReveal = { score, grade, color: GRADE_COLORS[grade] };
    }
    // Update extraction tags with enriched data
    const tagsEl = document.getElementById('extraction-tags');
    tagsEl.innerHTML = '';
    if (product_info.species)
      tagsEl.innerHTML += `<span class="tag">${product_info.species}</span>`;
    if (product_info.wild_or_farmed !== 'unknown')
      tagsEl.innerHTML += `<span class="tag">${product_info.wild_or_farmed}</span>`;
    if (product_info.origin_region)
      tagsEl.innerHTML += `<span class="tag">${product_info.origin_region}</span>`;
    if (product_info.fishing_method)
      tagsEl.innerHTML += `<span class="tag">${product_info.fishing_method}</span>`;
    product_info.certifications?.forEach(c =>
      tagsEl.innerHTML += `<span class="tag cert" data-cert="${c}">${c}</span>`);
    tagsEl.querySelectorAll('.tag.cert').forEach(tag => {
      tag.addEventListener('click', (e) => showCertPopover(tag.dataset.cert, e));
    });
    return;
  }

  if (data.phase === 'complete') {
    // Send final results to active voice session — this is when Gemini announces the score
    if (voiceClient && data.result) {
      voiceClient.sendContextUpdate({
        phase: 'complete',
        score: data.result.score,
        grade: data.result.grade,
        alternatives: data.result.alternatives,
        alternatives_label: data.result.alternatives_label,
        explanation: data.result.explanation,
      });
    } else if (voiceClient && data.page_type === 'product_listing' && data.products?.length > 0) {
      voiceClient.sendContextUpdate({
        phase: 'complete',
        page_type: 'product_listing',
        all_products: data.products.map(p => ({
          product_name: p.product_name,
          species: p.species,
          wild_or_farmed: p.wild_or_farmed,
          score: p.score,
          grade: p.grade,
        })),
        listing_summary: data.summary || '',
      });
    } else if (voiceClient && data.page_type === 'no_seafood') {
      voiceClient.sendContextUpdate({
        phase: 'complete',
        page_type: 'no_seafood',
      });
    }

    if (data.page_type === 'no_seafood') {
      showView('view-non-seafood');
    } else if (data.page_type === 'product_listing' && data.products?.length > 0) {
      renderProductList(data.products, data.summary || '', pageData?.relatedProductsWithUrls ?? []);
    } else if (data.result) {
      if (!data.result.product_info?.is_seafood) {
        showView('view-non-seafood');
        return;
      }
      currentResult = data.result;
      renderResult(data.result);
    }
    // Now that all results are in, reveal the score + grade.
    // Use the complete phase's final data (enrichment may have changed the score).
    if (_pendingScoreReveal) {
      const finalScore = data.result ? data.result.score : _pendingScoreReveal.score;
      const finalGrade = data.result ? data.result.grade : _pendingScoreReveal.grade;
      const finalColor = data.result ? GRADE_COLORS[finalGrade] : _pendingScoreReveal.color;
      _pendingScoreReveal = null;
      _animateScoreReveal(finalScore, finalGrade, finalColor);
    }
  }
}

// ── Progressive Phase 1: Animated score build ──
function renderScorePhase(data) {
  _cancelBuild();
  const { score, grade, breakdown, product_info } = data;
  const color = GRADE_COLORS[grade];

  // Grade badge — start gray with "?" (score revealed at the end)
  const gradeCircle = document.getElementById('grade-circle');
  gradeCircle.textContent = '?';
  gradeCircle.style.transition = 'none';
  gradeCircle.style.background = '#d1d5db';
  document.getElementById('grade-emoji-label').textContent = 'Building your score\u2026';
  document.getElementById('grade-score-text').innerHTML = '&nbsp;';

  // Price — show immediately (available from vision step)
  const priceEl = document.getElementById('grade-price');
  if (priceEl) {
    if (product_info.price) {
      priceEl.textContent = product_info.price;
      priceEl.style.display = '';
    } else {
      priceEl.style.display = 'none';
    }
  }

  // Clear content areas
  const tagsEl = document.getElementById('extraction-tags');
  tagsEl.innerHTML = '';
  document.getElementById('explanation-text').textContent = '';
  document.getElementById('breakdown-rows').innerHTML = '';

  // Collect tags
  const tags = [];
  if (product_info.species)
    tags.push({ text: product_info.species, cls: 'tag' });
  if (product_info.wild_or_farmed !== 'unknown')
    tags.push({ text: product_info.wild_or_farmed, cls: 'tag' });
  if (product_info.origin_region)
    tags.push({ text: product_info.origin_region, cls: 'tag' });
  if (product_info.fishing_method)
    tags.push({ text: product_info.fishing_method, cls: 'tag' });
  (product_info.certifications || []).forEach(c =>
    tags.push({ text: c, cls: 'tag cert', cert: c }));

  // Alternatives placeholder
  const altsCard = document.getElementById('alternatives-card');
  altsCard.style.display = 'block';
  document.getElementById('alternatives-title').textContent = 'Finding alternatives\u2026';
  document.getElementById('alternatives-list').innerHTML =
    '<div class="enriching-placeholder"><div class="spin-sm"></div>Loading alternatives &amp; explanation\u2026</div>';
  document.getElementById('category-page-tip').style.display = 'none';
  document.getElementById('not-right-link').style.display = 'none';

  showView('view-result');

  // ── ANIMATION SEQUENCE ──
  const TAG_STAGGER = 120;
  const EXPL_DELAY = tags.length * TAG_STAGGER + 250;
  const BAR_START = EXPL_DELAY + 300;
  const BAR_STAGGER = 300;

  // Step 1: Slide in tags one at a time
  tags.forEach((tag, i) => {
    _scheduleBuild(() => {
      const span = document.createElement('span');
      span.className = `${tag.cls} tag-animate`;
      span.textContent = tag.text;
      if (tag.cert) {
        span.dataset.cert = tag.cert;
        span.addEventListener('click', (e) => showCertPopover(tag.cert, e));
      }
      tagsEl.appendChild(span);
    }, i * TAG_STAGGER);
  });

  // Step 2: Fade in template explanation
  _scheduleBuild(() => {
    const el = document.getElementById('explanation-text');
    el.textContent = data.explanation || '';
    el.classList.remove('fade-in');
    void el.offsetWidth;
    el.classList.add('fade-in');
  }, EXPL_DELAY);

  // Step 3: Build breakdown bars one at a time
  const breakdownEl = document.getElementById('breakdown-rows');
  const factors = data.score_factors && data.score_factors.length > 0
    ? data.score_factors : null;
  const barItems = factors
    ? factors.map(f => ({
        label: f.category, val: f.score, max: f.max_score,
        explanation: f.explanation, tip: f.tip,
      }))
    : [
        { label: 'Biological Status', val: breakdown.biological, max: 20 },
        { label: product_info.wild_or_farmed === 'farmed'
            ? 'Aquaculture Practices' : 'Fishing Practices',
          val: breakdown.practices, max: 25 },
        { label: 'Management', val: breakdown.management, max: 30 },
        { label: 'Ecological', val: breakdown.ecological, max: 25 },
      ];

  barItems.forEach((item, i) => {
    _scheduleBuild(() => {
      const pct = Math.round((item.val / item.max) * 100);
      const barColor = pct >= 70 ? '#22c55e' : pct >= 45 ? '#eab308' : '#ef4444';
      const row = document.createElement('div');
      row.className = 'fade-in';

      if (item.explanation) {
        row.classList.add('breakdown-row');
        const tipHtml = item.tip
          ? `<div class="breakdown-tip">\u{1f4a1} ${escapeHtml(item.tip)}</div>` : '';
        row.innerHTML = `
          <div class="breakdown-header">
            <span class="score-label">${escapeHtml(item.label)}</span>
            <div style="display:flex; align-items:center; gap:8px;">
              <div class="score-bar-wrap">
                <div class="score-bar" style="width:0%; background:${barColor};"></div>
              </div>
              <span class="score-val">${Math.round(item.val)}/${item.max}</span>
              <span class="breakdown-chevron">\u25B6</span>
            </div>
          </div>
          <div class="breakdown-detail">
            ${escapeHtml(item.explanation)}
            ${tipHtml}
          </div>`;
        row.querySelector('.breakdown-header').addEventListener('click', () => {
          row.classList.toggle('open');
        });
      } else {
        row.classList.add('score-row');
        row.innerHTML = `
          <span class="score-label">${escapeHtml(item.label)}</span>
          <div style="display:flex; align-items:center; gap:8px;">
            <div class="score-bar-wrap">
              <div class="score-bar" style="width:0%; background:${barColor};"></div>
            </div>
            <span class="score-val">${Math.round(item.val)}/${item.max}</span>
          </div>`;
      }

      breakdownEl.appendChild(row);
      // Animate bar from 0 to final width
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          row.querySelector('.score-bar').style.width = `${pct}%`;
        });
      });
    }, BAR_START + i * BAR_STAGGER);
  });

  // Score reveal is deferred until 'complete' phase arrives
  _pendingScoreReveal = { score, grade, color };

  // Start voice if not already connected — skip "scored" context update
  // to avoid Gemini speaking twice (once for scored, once for complete).
  // The "complete" phase (line ~455) sends the final score to Gemini.
  if (!voiceClient) {
    startVoiceAfterResult({ score, grade, product_info });
  }
}

function _animateScoreReveal(targetScore, grade, color) {
  const gradeCircle = document.getElementById('grade-circle');
  const scoreText = document.getElementById('grade-score-text');
  const gradeLabel = document.getElementById('grade-emoji-label');

  // Grade circle: pop in with final color + letter
  gradeCircle.style.transition = 'background 0.4s ease';
  gradeCircle.style.background = color;
  gradeCircle.textContent = grade;
  gradeCircle.classList.remove('grade-pop');
  void gradeCircle.offsetWidth;
  gradeCircle.classList.add('grade-pop');

  // Count up score (ease-out cubic)
  const duration = 500;
  const start = performance.now();
  function tick(now) {
    const t = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - t, 3);
    scoreText.textContent = `${Math.round(eased * targetScore)}/100`;
    if (t < 1) {
      requestAnimationFrame(tick);
    } else {
      scoreText.textContent = `${targetScore}/100`;
      gradeLabel.textContent = GRADE_LABELS[grade];
    }
  }
  requestAnimationFrame(tick);
}

document.getElementById('analyze-btn')?.addEventListener('click', triggerAnalyze);
document.getElementById('analyze-again-btn')?.addEventListener('click', triggerAnalyze);
document.getElementById('list-analyze-again-btn')?.addEventListener('click', triggerAnalyze);
document.getElementById('non-seafood-back-btn')?.addEventListener('click', () => showView('view-idle'));
document.getElementById('error-retry-btn')?.addEventListener('click', triggerAnalyze);
document.getElementById('error-back-btn')?.addEventListener('click', () => showView('view-idle'));

// ── Client-side URL matching for product cards ──
const _URL_STOPWORDS = new Set(['the','a','an','of','and','or','in','at','to','with','for','lb','oz']);
function _findUrl(productName, urlMap) {
  if (!productName || !urlMap?.length) return null;
  const nameLower = productName.trim().toLowerCase();
  for (const entry of urlMap) {
    const titleLower = (entry.title || '').trim().toLowerCase();
    if (!titleLower || !entry.url) continue;
    if (nameLower === titleLower) return entry.url;
    if (nameLower.includes(titleLower) || titleLower.includes(nameLower)) return entry.url;
  }
  const nameTokens = new Set(nameLower.split(/\s+/).filter(t => !_URL_STOPWORDS.has(t) && t.length > 2));
  let bestUrl = null, bestOverlap = 1;
  for (const entry of urlMap) {
    if (!entry.url) continue;
    const titleTokens = new Set((entry.title || '').toLowerCase().split(/\s+/).filter(t => !_URL_STOPWORDS.has(t) && t.length > 2));
    let overlap = 0;
    for (const t of nameTokens) { if (titleTokens.has(t)) overlap++; }
    if (overlap > bestOverlap) { bestOverlap = overlap; bestUrl = entry.url; }
  }
  return bestUrl;
}

// ── Render Product List (multi-product) ──
function renderProductList(products, summary, urlMap = []) {
  const container = document.getElementById('product-list');
  const badge = document.getElementById('list-count-badge');
  if (!container) return;

  badge.textContent = products.length;
  container.innerHTML = '';

  // Show comparative summary
  const summaryEl = document.getElementById('listing-summary');
  if (summaryEl) {
    if (summary) {
      summaryEl.textContent = summary;
      summaryEl.style.display = '';
    } else {
      summaryEl.style.display = 'none';
    }
  }

  products.forEach(product => {
    const color = GRADE_COLORS[product.grade] || '#6b7280';
    const gradeLabel = GRADE_LABELS[product.grade] || '';

    const item = document.createElement('div');
    item.className = 'product-list-item';

    // Meta tags
    let metaHtml = '';
    if (product.species)
      metaHtml += `<span class="tag">${product.species}</span>`;
    if (product.wild_or_farmed && product.wild_or_farmed !== 'unknown')
      metaHtml += `<span class="tag">${escapeHtml(product.wild_or_farmed)}</span>`;
    if (product.certifications?.length > 0)
      product.certifications.forEach(c => { metaHtml += `<span class="tag cert">${escapeHtml(c)}</span>`; });

    // Breakdown bars
    const bd = product.breakdown;
    const rows = [
      ['Biological', bd.biological, BREAKDOWN_MAX.biological],
      ['Practices',  bd.practices,  BREAKDOWN_MAX.practices],
      ['Management', bd.management, BREAKDOWN_MAX.management],
      ['Ecological', bd.ecological, BREAKDOWN_MAX.ecological],
    ];
    const breakdownHtml = rows.map(([label, val, max]) => {
      const pct = Math.round((val / max) * 100);
      const barColor = pct >= 70 ? '#22c55e' : pct >= 45 ? '#eab308' : '#ef4444';
      return `
        <div class="score-row">
          <span class="score-label">${label}</span>
          <div style="display:flex; align-items:center; gap:8px;">
            <div class="score-bar-wrap">
              <div class="score-bar" style="width:${pct}%; background:${barColor};"></div>
            </div>
            <span class="score-val">${Math.round(val)}/${max}</span>
          </div>
        </div>`;
    }).join('');

    const priceHtml = product.price
      ? `<div class="list-price">${escapeHtml(product.price)}</div>` : '';

    const productUrl = product.url || _findUrl(product.product_name, urlMap);

    item.innerHTML = `
      <div class="list-header${productUrl ? ' list-header-clickable' : ''}">
        <div class="list-grade-circle" style="background:${color}">${escapeHtml(product.grade)}</div>
        <div class="list-product-body">
          <div class="list-product-name" title="${escapeHtml(product.product_name)}">${escapeHtml(product.product_name)}</div>
          <div class="list-product-meta">${metaHtml}</div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
          <span class="list-score-text">${product.score}</span>
          ${priceHtml}
        </div>
        <span class="list-chevron">▶</span>
      </div>
      <div class="list-breakdown">${breakdownHtml}</div>`;

    // Chevron always toggles expand/collapse (stops propagation so card click doesn't fire)
    item.querySelector('.list-chevron').addEventListener('click', (e) => {
      e.stopPropagation();
      item.classList.toggle('open');
    });

    // Card click: navigate to product page then auto-analyze
    item.querySelector('.list-header').addEventListener('click', async () => {
      if (productUrl) {
        stopVoiceBar();
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab?.id) return;
        chrome.tabs.update(tab.id, { url: productUrl });

        // Auto-analyze once the product page finishes loading
        const tabId = tab.id;
        let cleanup;
        const timeout = setTimeout(() => { cleanup(); }, 20000);
        const listener = (updatedId, info) => {
          if (updatedId !== tabId || info.status !== 'complete') return;
          cleanup();
          // Brief pause for SPA rendering before analyzing
          setTimeout(() => triggerAnalyze(), 1500);
        };
        cleanup = () => {
          chrome.tabs.onUpdated.removeListener(listener);
          clearTimeout(timeout);
        };
        chrome.tabs.onUpdated.addListener(listener);
      } else {
        item.classList.toggle('open');
      }
    });

    container.appendChild(item);
  });

  showView('view-results-list');

  if (products.length > 0) {
    startVoiceAfterResult({
      score: products[0].score,
      grade: products[0].grade,
      product_info: { species: products[0].species ?? null, wild_or_farmed: products[0].wild_or_farmed ?? 'unknown' },
      all_products: products.map(p => ({
        product_name: p.product_name,
        species: p.species,
        wild_or_farmed: p.wild_or_farmed,
        score: p.score,
        grade: p.grade,
      })),
      listing_summary: summary || '',
    });
  }
}

// ── Render Result ──
function renderResult(data) {
  _cancelBuild();
  const { score, grade, breakdown, alternatives, alternatives_label,
          explanation, score_factors, product_info } = data;
  const color = GRADE_COLORS[grade];

  // Grade badge — skip if pending reveal will animate it
  if (!_pendingScoreReveal) {
    document.getElementById('grade-circle').textContent = grade;
    document.getElementById('grade-circle').style.background = color;
    document.getElementById('grade-emoji-label').textContent = GRADE_LABELS[grade];
    document.getElementById('grade-score-text').textContent = `${score}/100`;
  }

  // Price
  const priceEl = document.getElementById('grade-price');
  if (priceEl) {
    if (product_info.price) {
      priceEl.textContent = product_info.price;
      priceEl.style.display = '';
    } else {
      priceEl.style.display = 'none';
    }
  }

  // Extraction tags
  const tagsEl = document.getElementById('extraction-tags');
  tagsEl.innerHTML = '';
  if (product_info.species)
    tagsEl.innerHTML += `<span class="tag">${escapeHtml(product_info.species)}</span>`;
  if (product_info.wild_or_farmed !== 'unknown')
    tagsEl.innerHTML += `<span class="tag">${escapeHtml(product_info.wild_or_farmed)}</span>`;
  if (product_info.origin_region)
    tagsEl.innerHTML += `<span class="tag">${escapeHtml(product_info.origin_region)}</span>`;
  if (product_info.fishing_method)
    tagsEl.innerHTML += `<span class="tag">${escapeHtml(product_info.fishing_method)}</span>`;
  product_info.certifications?.forEach(c =>
    tagsEl.innerHTML += `<span class="tag cert" data-cert="${escapeHtml(c)}">${escapeHtml(c)}</span>`);

  tagsEl.querySelectorAll('.tag.cert').forEach(tag => {
    tag.addEventListener('click', (e) => showCertPopover(tag.dataset.cert, e));
  });

  // Explanation
  document.getElementById('explanation-text').textContent = explanation;

  // Breakdown rows
  const breakdownEl = document.getElementById('breakdown-rows');
  if (score_factors && score_factors.length > 0) {
    breakdownEl.innerHTML = score_factors.map(factor => {
      const pct = Math.round((factor.score / factor.max_score) * 100);
      const barColor = pct >= 70 ? '#22c55e' : pct >= 45 ? '#eab308' : '#ef4444';
      const tipHtml = factor.tip
        ? `<div class="breakdown-tip">💡 ${escapeHtml(factor.tip)}</div>` : '';
      return `
        <div class="breakdown-row">
          <div class="breakdown-header">
            <span class="score-label">${escapeHtml(factor.category)}</span>
            <div style="display:flex; align-items:center; gap:8px;">
              <div class="score-bar-wrap">
                <div class="score-bar" style="width:${pct}%; background:${barColor};"></div>
              </div>
              <span class="score-val">${Math.round(factor.score)}/${factor.max_score}</span>
              <span class="breakdown-chevron">▶</span>
            </div>
          </div>
          <div class="breakdown-detail">
            ${escapeHtml(factor.explanation)}
            ${tipHtml}
          </div>
        </div>`;
    }).join('');

    breakdownEl.querySelectorAll('.breakdown-header').forEach(header => {
      header.addEventListener('click', () => {
        header.parentElement.classList.toggle('open');
      });
    });
  } else {
    // Fallback: static breakdown rows (no score_factors)
    const practicesLabel = product_info.wild_or_farmed === 'farmed'
      ? 'Aquaculture Practices' : 'Fishing Practices';
    const rows = [
      ['Biological Status', breakdown.biological, BREAKDOWN_MAX.biological],
      [practicesLabel,      breakdown.practices,  BREAKDOWN_MAX.practices],
      ['Management',        breakdown.management, BREAKDOWN_MAX.management],
      ['Ecological',        breakdown.ecological, BREAKDOWN_MAX.ecological],
    ];
    breakdownEl.innerHTML = rows.map(([label, val, max]) => {
      const pct = Math.round((val / max) * 100);
      const barColor = pct >= 70 ? '#22c55e' : pct >= 45 ? '#eab308' : '#ef4444';
      return `
        <div class="score-row">
          <span class="score-label">${label}</span>
          <div style="display:flex; align-items:center; gap:8px;">
            <div class="score-bar-wrap">
              <div class="score-bar" style="width:${pct}%; background:${barColor};"></div>
            </div>
            <span class="score-val">${Math.round(val)}/${max}</span>
          </div>
        </div>`;
    }).join('');
  }

  // Show not-right link (may have been hidden during progressive Phase 1)
  document.getElementById('not-right-link').style.display = '';

  // Alternatives
  const altsCard  = document.getElementById('alternatives-card');
  const altsList  = document.getElementById('alternatives-list');
  const altsTitle = document.getElementById('alternatives-title');

  if (alternatives && alternatives.length > 0) {
    altsCard.style.display = 'block';
    altsTitle.textContent = alternatives_label || 'Better alternatives';
    altsList.innerHTML = alternatives.map(alt => {
      const altColor = GRADE_COLORS[alt.grade];
      const fromPageNote = alt.from_page
        ? '' : '<div class="alt-from-page">(check if available on this site)</div>';
      return `
        <div class="alt-row">
          <div>
            <div class="alt-name">${escapeHtml(alt.species)}</div>
            <div class="alt-reason">${escapeHtml(alt.reason)}</div>
            ${fromPageNote}
          </div>
          <span class="alt-badge" style="background:${altColor}">${escapeHtml(alt.grade)}</span>
        </div>`;
    }).join('');

    const tip = document.getElementById('category-page-tip');
    const hasSeedOnly = alternatives.every(a => !a.from_page);
    if (hasSeedOnly && grade !== 'A') {
      tip.style.display = 'block';
      tip.textContent = 'Want options available on this site? Navigate to the seafood section and click Analyze again.';
    } else {
      tip.style.display = 'none';
    }
  } else {
    altsCard.style.display = 'none';
  }

  // Render health + food miles if present in complete result
  if (data.health) renderHealthCard(data.health);
  if (data.food_miles) renderFoodMilesCard(data.food_miles);

  showView('view-result');
  if (!voiceClient) {
    startVoiceAfterResult(data);
  }
}

// ── Cert popover ──
function showCertPopover(certName, event) {
  const certKey = certName.toUpperCase();
  let def = null;
  for (const [key, val] of Object.entries(CERT_DEFINITIONS)) {
    if (certKey === key || certKey.includes(key) || key.includes(certKey)) {
      def = val; break;
    }
  }
  if (!def) return;

  const popover = document.getElementById('cert-popover');
  document.getElementById('cert-popover-title').textContent = def.full_name;
  document.getElementById('cert-popover-body').textContent = def.explanation;

  const rect = event.currentTarget.getBoundingClientRect();
  const panelWidth = document.body.offsetWidth;
  let left = rect.left;
  if (left + 240 > panelWidth - 8) left = panelWidth - 248;
  if (left < 8) left = 8;
  popover.style.top  = `${rect.bottom + 6}px`;
  popover.style.left = `${left}px`;
  popover.classList.add('visible');
  event.stopPropagation();
}

document.addEventListener('click', (e) => {
  if (e.target?.id !== 'cert-popover-close') {
    document.getElementById('cert-popover')?.classList.remove('visible');
  }
});
document.getElementById('cert-popover-close')?.addEventListener('click', (e) => {
  document.getElementById('cert-popover')?.classList.remove('visible');
  e.stopPropagation();
});

// ── "Not right?" correction ──
document.getElementById('not-right-link')?.addEventListener('click', () => {
  if (!currentResult) return;
  const p = currentResult.product_info;
  document.getElementById('corr-species').value      = p.species || '';
  document.getElementById('corr-wild-farmed').value  = p.wild_or_farmed || 'unknown';
  document.getElementById('corr-method').value       = p.fishing_method || '';
  document.getElementById('corr-origin').value       = p.origin_region || '';
  document.getElementById('corr-certs').value        = (p.certifications || []).join(', ');
  showView('view-correction');
});

document.getElementById('correction-cancel-btn')?.addEventListener('click', () => {
  showView('view-result');
});

document.getElementById('correction-submit-btn')?.addEventListener('click', async () => {
  const certsRaw = document.getElementById('corr-certs').value;
  const certs = certsRaw.split(',').map(s => s.trim()).filter(Boolean);

  const correctedInfo = {
    is_seafood: true,
    species:         document.getElementById('corr-species').value.trim() || null,
    wild_or_farmed:  document.getElementById('corr-wild-farmed').value,
    fishing_method:  document.getElementById('corr-method').value || null,
    origin_region:   document.getElementById('corr-origin').value.trim() || null,
    certifications:  certs,
  };

  showView('view-loading');

  try {
    const response = await fetch(`${BACKEND_URL}/score`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product_info: correctedInfo }),
      signal: AbortSignal.timeout(10000),
    });

    if (!response.ok) throw new Error(`Backend error ${response.status}`);

    currentResult = await response.json();
    renderResult(currentResult);
  } catch (err) {
    showError(err.message);
  }
});

// ── Cooldown UI ──
function startCooldownUI(secondsRemaining) {
  const BUTTON_IDS = ['analyze-btn', 'analyze-again-btn', 'list-analyze-again-btn'];
  const ORIGINAL_LABELS = {
    'analyze-btn': 'Analyze This Page',
    'analyze-again-btn': 'Analyze Again',
    'list-analyze-again-btn': 'Analyze Again',
  };

  let secs = secondsRemaining;

  // Clear any existing cooldown timer to prevent leaks
  if (_cooldownInterval) clearInterval(_cooldownInterval);

  BUTTON_IDS.forEach(id => {
    const btn = document.getElementById(id);
    if (!btn) return;
    btn.disabled = true;
    btn.textContent = `Wait ${secs}s…`;
  });

  _cooldownInterval = setInterval(() => {
    secs -= 1;
    if (secs <= 0) {
      clearInterval(_cooldownInterval);
      _cooldownInterval = null;
      BUTTON_IDS.forEach(id => {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.disabled = false;
        btn.textContent = ORIGINAL_LABELS[id];
      });
    } else {
      BUTTON_IDS.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) btn.textContent = `Wait ${secs}s…`;
      });
    }
  }, 1000);

  // Stay on current view — don't redirect to error
}

// ── Error ──
function showError(message) {
  document.getElementById('error-message').textContent =
    message || 'Something went wrong. Please try again.';
  showView('view-error');
}
