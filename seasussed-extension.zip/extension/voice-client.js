// extension/voice-client.js
// Manages the full voice session lifecycle: WebSocket connection, microphone
// capture, PCM encoding, audio playback, and screenshot bridge.
// Requires: BACKEND_URL global (from config.js, loaded before this script).

/* global BACKEND_URL */

class VoiceClient {
  constructor() {
    this.ws = null;
    this.audioContext = null;
    this.micStream = null;
    this.workletNode = null;
    this.nextPlayTime = 0;
    this._receivedFirstAudio = false;
    this.onStatus = () => {};
    this.onScoreResult = () => {};
    this.onError = () => {};
    this.onAudioActivity = () => {}; // fires each time a mic chunk is sent
    this._pendingNavigateUrl = null;
    this._navigateListener = null;
    this._navigateTimeout = null;
    this._userInitiatedClose = false;
    this._reconnectAttempts = 0;
    this._maxReconnectAttempts = 3;
    this._lastResultContext = null;
    this._sessionEndCode = null;
    this._sessionEndReason = null;
  }

  // ── Public API ──────────────────────────────────────────

  async start(preAcquiredStream = null) {
    // 1. Get microphone (use pre-acquired stream if provided to avoid re-requesting permission)
    console.log('[SeaSussed] VoiceClient.start() — acquiring mic…');
    this.micStream = preAcquiredStream ?? await navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true },
    });
    console.log('[SeaSussed] Mic acquired, tracks:', this.micStream.getTracks().map(t => t.readyState));

    // 2. Create AudioContext for playback (24kHz to match Gemini output)
    this.audioContext = new AudioContext({ sampleRate: 24000 });
    if (this.audioContext.state === 'suspended') {
      console.log('[SeaSussed] AudioContext suspended, resuming…');
      await this.audioContext.resume();
    }
    console.log('[SeaSussed] AudioContext state:', this.audioContext.state, 'sampleRate:', this.audioContext.sampleRate);
    this.nextPlayTime = this.audioContext.currentTime;

    // 3. Separate AudioContext for mic capture at 16kHz
    this._micContext = new AudioContext({ sampleRate: 16000 });
    if (this._micContext.state === 'suspended') {
      await this._micContext.resume();
    }

    // 4. Load AudioWorklet on the mic context
    await this._micContext.audioWorklet.addModule(
      chrome.runtime.getURL('audio-worklet-processor.js')
    );
    console.log('[SeaSussed] AudioWorklet loaded');

    // 5. Open WebSocket to backend
    const wsUrl = BACKEND_URL
      .replace('https://', 'wss://')
      .replace('http://', 'ws://');
    console.log('[SeaSussed] Opening WebSocket to', wsUrl + '/voice');
    this.ws = new WebSocket(wsUrl + '/voice');
    await this._waitForOpen();
    console.log('[SeaSussed] WebSocket connected');

    // 6. Set up message and lifecycle handlers (AFTER _waitForOpen so they aren't overwritten)
    this._setupWsHandlers();

    // 7. Wire mic → AudioWorklet → WebSocket
    const source = this._micContext.createMediaStreamSource(this.micStream);
    this.workletNode = new AudioWorkletNode(this._micContext, 'pcm-processor');
    this.workletNode.port.onmessage = (e) => this._sendAudioChunk(e.data);
    source.connect(this.workletNode);
    // workletNode is NOT connected to destination — prevents mic echo
    console.log('[SeaSussed] Mic wired to worklet, audio flowing');
  }

  sendResultContext(ctx) {
    this._lastResultContext = ctx;
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'result_context', ...ctx }));
  }

  sendContextUpdate(update) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'context_update', ...update }));
  }

  stop() {
    this._userInitiatedClose = true;
    if (this._navigateListener) {
      chrome.tabs.onUpdated.removeListener(this._navigateListener);
      this._navigateListener = null;
    }
    if (this._navigateTimeout) {
      clearTimeout(this._navigateTimeout);
      this._navigateTimeout = null;
    }
    this._pendingNavigateUrl = null;
    if (this.ws) {
      if (this.ws.readyState === WebSocket.OPEN) {
        try { this.ws.send(JSON.stringify({ type: 'stop' })); } catch (_) {}
      }
      this.ws.close();
      this.ws = null;
    }
    this._cleanupAudio();
  }

  // ── Private Methods ──────────────────────────────────────

  _sendAudioChunk(arrayBuffer) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      return;
    }
    const uint8 = new Uint8Array(arrayBuffer);
    // Build base64 in chunks to avoid stack overflow with spread operator
    let binary = '';
    for (let i = 0; i < uint8.length; i++) {
      binary += String.fromCharCode(uint8[i]);
    }
    const b64 = btoa(binary);
    this.ws.send(JSON.stringify({ type: 'audio', data: b64 }));
    this.onAudioActivity();
  }

  async _handleMessage(msg) {
    switch (msg.type) {
      case 'audio':
        if (!this._receivedFirstAudio) {
          this._receivedFirstAudio = true;
          console.log('[SeaSussed] First audio chunk from server');
          this.onStatus('speaking');
        }
        this._playAudioChunk(msg.data);
        break;
      case 'request_screenshot':
        await this._captureAndSendScreenshot();
        break;
      case 'search_store':
        await this._searchStoreAndSend(msg.query);
        break;
      case 'navigate':
        await this._navigateToUrl(msg.url);
        break;
      case 'score_result':
        this.onScoreResult(msg.score);
        break;
      case 'status':
        console.log('[SeaSussed] Status from server:', msg.state);
        if (msg.state === 'listening') this._receivedFirstAudio = false;
        if (msg.state !== 'connecting') this.onStatus(msg.state);
        break;
      case 'error':
        console.error('[SeaSussed] Error from server:', msg.message);
        this.onError(msg.message);
        break;
      case 'session_end':
        console.warn('[SeaSussed] Session end:', msg.code, msg.reason);
        this._sessionEndCode = msg.code;
        this._sessionEndReason = msg.reason;
        break;
      case 'ping':
        break; // no-op keepalive
    }
  }

  _playAudioChunk(b64) {
    if (!this.audioContext || this.audioContext.state === 'closed') {
      return;
    }

    try {
      // Decode base64 -> bytes
      const binary = atob(b64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }

      // Ensure even byte length for Int16 conversion
      const usableLength = bytes.length & ~1;
      if (usableLength === 0) return;

      // Interpret as Int16 (24kHz, 16-bit PCM) -> Float32
      const int16 = new Int16Array(bytes.buffer, 0, usableLength / 2);
      const float32 = new Float32Array(int16.length);
      for (let i = 0; i < int16.length; i++) {
        float32[i] = int16[i] / 32768.0;
      }

      // Create AudioBuffer (24kHz, mono) and schedule gapless playback
      const buffer = this.audioContext.createBuffer(1, float32.length, 24000);
      buffer.getChannelData(0).set(float32);

      const source = this.audioContext.createBufferSource();
      source.buffer = buffer;
      source.connect(this.audioContext.destination);

      const startTime = Math.max(this.audioContext.currentTime, this.nextPlayTime);
      source.start(startTime);
      this.nextPlayTime = startTime + buffer.duration;
    } catch (err) {
      console.warn('[SeaSussed] Audio playback error (non-fatal):', err.message);
    }
  }

  async _captureAndSendScreenshot() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab?.id) {
      return;
    }

    const result = await chrome.runtime.sendMessage({
      type: 'CAPTURE_SCREENSHOT_FOR_VOICE',
      tabId: tab.id,
      url: tab.url,
      pageTitle: tab.title ?? '',
    });

    if (result.error) {
      this.ws.send(JSON.stringify({
        type: 'screenshot',
        data: '',
        url: tab.url ?? '',
        page_title: tab.title ?? '',
        related_products: [],
        error: result.error,
      }));
      return;
    }

    this.ws.send(JSON.stringify({
      type: 'screenshot',
      data: result.screenshot,
      url: result.url,
      page_title: result.page_title,
      related_products: result.related_products,
    }));
  }

  async _searchStoreAndSend(query) {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab?.id) return;

    const result = await chrome.runtime.sendMessage({
      type: 'SEARCH_STORE_FOR_VOICE',
      tabId: tab.id,
      url: tab.url,
      query,
    });

    if (result.error) {
      this.ws.send(JSON.stringify({
        type: 'search_results',
        data: '',
        url: '',
        page_title: '',
        error: result.error,
      }));
      return;
    }

    this.ws.send(JSON.stringify({
      type: 'search_results',
      data: result.screenshot,
      url: result.url,
      page_title: result.page_title,
      page_text: result.page_text || '',
      product_links: result.product_links || [],
    }));
  }

  async _navigateToUrl(url) {
    // Guard: skip if already navigating to this URL
    if (this._pendingNavigateUrl === url) {
      console.log('[SeaSussed] Skipping duplicate navigate to:', url);
      return;
    }

    // Clean up any pending navigation listener
    if (this._navigateListener) {
      chrome.tabs.onUpdated.removeListener(this._navigateListener);
      this._navigateListener = null;
    }
    if (this._navigateTimeout) {
      clearTimeout(this._navigateTimeout);
      this._navigateTimeout = null;
    }

    this._pendingNavigateUrl = url;

    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab?.id || !url) return;
    await chrome.tabs.update(tab.id, { url });

    // Wait for the new page to finish loading, then poll for product
    // content before triggering analysis (SPA pages render after load).
    const tabId = tab.id;
    this._navigateListener = (updatedId, info) => {
      if (updatedId === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(this._navigateListener);
        clearTimeout(this._navigateTimeout);
        this._navigateListener = null;
        this._navigateTimeout = null;
        this._pendingNavigateUrl = null;
        this._waitForProductContent(tabId).then(() => {
          if (typeof triggerAnalyze === 'function') triggerAnalyze();
        });
      }
    };
    this._navigateTimeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(this._navigateListener);
      this._navigateListener = null;
      this._navigateTimeout = null;
      this._pendingNavigateUrl = null;
    }, 15000);
    chrome.tabs.onUpdated.addListener(this._navigateListener);
  }

  async _waitForProductContent(tabId) {
    // Poll until the page has a product title or substantial content.
    // SPA grocery sites (React/Next.js) often render after the load event.
    const maxWait = 8000;
    const interval = 500;
    let elapsed = 0;
    while (elapsed < maxWait) {
      await new Promise(r => setTimeout(r, interval));
      elapsed += interval;
      try {
        const [result] = await chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const titleSels = [
              '#productTitle', '#title', 'h1',
              '[data-testid*="product-title"]', '[class*="ProductTitle"]',
              '[class*="product-title"]', '[class*="ProductName"]',
            ];
            for (const sel of titleSels) {
              const el = document.querySelector(sel);
              if (el && el.innerText.trim().length > 3) return true;
            }
            // Fallback: check for substantial main content
            const main = document.querySelector('main, [role="main"]');
            return main ? main.innerText.trim().length > 500 : false;
          },
        });
        if (result?.result) return;
      } catch {
        // scripting might fail on certain pages — keep waiting
      }
    }
    // Timed out — proceed anyway with whatever is rendered
  }

  _setupWsHandlers() {
    this.ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        this._handleMessage(msg).catch(err => {
          console.error('[SeaSussed] Error in _handleMessage:', err);
        });
      } catch (parseErr) {
        console.error('[SeaSussed] Failed to parse WS message:', parseErr);
      }
    };
    this.ws.onclose = (event) => {
      const code = this._sessionEndCode || event.code;
      console.warn('[SeaSussed] WebSocket closed — code:', code,
        'frame:', event.code, 'reason:', this._sessionEndReason || event.reason || '(none)');
      this._sessionEndCode = null;
      this._sessionEndReason = null;

      if (this._userInitiatedClose) {
        this.onStatus('ended');
        return;
      }

      if (code === 4000) {
        this._cleanupAudio();
        this.onStatus('expired');
        return;
      }

      if (code === 4001) {
        this._cleanupAudio();
        this.onStatus('disconnected');
        return;
      }

      if (code === 1005 || code === 1006) {
        if (this._reconnectAttempts < this._maxReconnectAttempts) {
          this.onStatus('reconnecting');
          this._reconnect().catch(() => {
            this._cleanupAudio();
            this.onStatus('disconnected');
          });
          return;
        }
        this._cleanupAudio();
        this.onStatus('disconnected');
        return;
      }

      this.onStatus('ended');
    };
    this.ws.onerror = (event) => {
      console.error('[SeaSussed] WebSocket error:', event);
    };
  }

  async _reconnect() {
    this._reconnectAttempts++;
    const delay = Math.min(1000 * Math.pow(2, this._reconnectAttempts - 1), 4000);
    console.log(`[SeaSussed] Reconnect attempt ${this._reconnectAttempts}/${this._maxReconnectAttempts} in ${delay}ms`);
    await new Promise(r => setTimeout(r, delay));

    if (!this.micStream || this.micStream.getTracks().every(t => t.readyState === 'ended')) {
      throw new Error('Mic stream ended during reconnect');
    }

    const wsUrl = BACKEND_URL.replace('https://', 'wss://').replace('http://', 'ws://');
    this.ws = new WebSocket(wsUrl + '/voice');
    await this._waitForOpen();

    this._setupWsHandlers();

    this.nextPlayTime = this.audioContext.currentTime;
    this._receivedFirstAudio = false;

    if (this._lastResultContext) {
      this.sendResultContext(this._lastResultContext);
    }

    this._reconnectAttempts = 0;
    console.log('[SeaSussed] Reconnected successfully');
  }

  _cleanupAudio() {
    if (this.workletNode) {
      this.workletNode.disconnect();
      this.workletNode = null;
    }
    if (this.micStream) {
      this.micStream.getTracks().forEach(t => t.stop());
      this.micStream = null;
    }
    if (this._micContext) {
      this._micContext.close();
      this._micContext = null;
    }
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
  }

  _waitForOpen() {
    return new Promise((resolve, reject) => {
      const cleanup = () => {
        clearTimeout(timer);
      };
      const timer = setTimeout(() => {
        cleanup();
        reject(new Error('WebSocket open timed out'));
      }, 5000);
      this.ws.onopen = () => {
        cleanup();
        resolve();
      };
      this.ws.onerror = (event) => {
        cleanup();
        reject(new Error('WebSocket connection failed'));
      };
      this.ws.onclose = (event) => {
        cleanup();
        reject(new Error(`WebSocket closed during connect: code=${event.code}`));
      };
    });
  }
}
